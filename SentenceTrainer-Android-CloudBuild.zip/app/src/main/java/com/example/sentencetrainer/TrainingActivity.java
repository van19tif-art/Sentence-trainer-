package com.example.sentencetrainer;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class TrainingActivity extends AppCompatActivity {
    private ArrayList<Integer> order=new ArrayList<>(); private int pos=0; private int currentId; private LinkedHashMap<Integer,String[]> data; private TextView ar,en; private Button show,next;
    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_training); ar=findViewById(R.id.arabicText);en=findViewById(R.id.englishText);show=findViewById(R.id.showButton);next=findViewById(R.id.nextButton); data=SentenceStore.load(this); buildRound(); show.setOnClickListener(v->reveal()); next.setOnClickListener(v->nextSentence());}
    private void buildRound(){order.clear();order.addAll(data.keySet());Collections.shuffle(order);pos=0;showCurrent();}
    private void showCurrent(){currentId=order.get(pos);String[] s=data.get(currentId);ar.setText(s[0]);en.setText(s[1]);en.setVisibility(View.GONE);show.setEnabled(true);}
    private void reveal(){en.setVisibility(View.VISIBLE);show.setEnabled(false);}
    private void nextSentence(){pos++; if(pos>=order.size()){Toast.makeText(this,"انتهت الجولة — تم إنشاء ترتيب عشوائي جديد.",Toast.LENGTH_SHORT).show();buildRound();}else showCurrent();}
}
