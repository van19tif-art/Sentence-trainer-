package com.example.sentencetrainer;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView add = findViewById(R.id.addButton);
        Button start = findViewById(R.id.startButton);
        add.setOnClickListener(v -> startActivity(new Intent(this, AddSentencesActivity.class)));
        start.setOnClickListener(v -> {
            if (SentenceStore.count(this) == 0) {
                Toast.makeText(this, "أضف الجمل أولاً بالضغط على +", Toast.LENGTH_SHORT).show();
            } else startActivity(new Intent(this, TrainingActivity.class));
        });
    }
}
