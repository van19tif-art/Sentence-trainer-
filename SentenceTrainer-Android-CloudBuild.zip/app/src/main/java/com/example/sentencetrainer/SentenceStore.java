package com.example.sentencetrainer;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.LinkedHashMap;
import java.util.Map;

public final class SentenceStore {
    private static final String PREF="sentences_pref";
    private static final String KEY="sentences";
    private SentenceStore() {}
    public static void save(Context c, Map<Integer,String[]> data) {
        JSONArray a=new JSONArray();
        try { for(Map.Entry<Integer,String[]> e:data.entrySet()) { JSONObject o=new JSONObject(); o.put("id",e.getKey()); o.put("ar",e.getValue()[0]); o.put("en",e.getValue()[1]); a.put(o); } }
        catch(Exception ignored){}
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(KEY,a.toString()).apply();
    }
    public static LinkedHashMap<Integer,String[]> load(Context c) {
        LinkedHashMap<Integer,String[]> out=new LinkedHashMap<>(); String s=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY,"[]");
        try { JSONArray a=new JSONArray(s); for(int i=0;i<a.length();i++){ JSONObject o=a.getJSONObject(i); out.put(o.getInt("id"),new String[]{o.getString("ar"),o.getString("en")}); } } catch(Exception ignored){} return out;
    }
    public static int count(Context c){ return load(c).size(); }
}
