package com.example.sentencetrainer;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;
import java.util.regex.*;

public class AddSentencesActivity extends AppCompatActivity {
    private static final Pattern P=Pattern.compile("^\\s*(\\d+)\\s*[-.)：:]\\s*(.+?)\\s*$");
    @Override protected void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_add);
        EditText ar=findViewById(R.id.arabicInput), en=findViewById(R.id.englishInput); Button save=findViewById(R.id.saveButton);
        save.setOnClickListener(v -> {
            Map<Integer,String> am=parse(ar.getText().toString()), em=parse(en.getText().toString());
            if(am.isEmpty()||em.isEmpty()){Toast.makeText(this,"تأكد من لصق الجمل العربية والإنجليزية المرقمة.",Toast.LENGTH_LONG).show();return;}
            LinkedHashMap<Integer,String[]> data=new LinkedHashMap<>(); int missing=0;
            for(Map.Entry<Integer,String> e:am.entrySet()){ String x=em.get(e.getKey()); if(x!=null) data.put(e.getKey(),new String[]{e.getValue(),x}); else missing++; }
            if(data.isEmpty()){Toast.makeText(this,"لم أجد أرقاماً مشتركة بين القائمتين.",Toast.LENGTH_LONG).show();return;}
            SentenceStore.save(this,data);
            String msg="تم حفظ "+data.size()+" جملة"+(missing>0?"، وتم تجاهل "+missing+" جملة بلا ترجمة":"");
            Toast.makeText(this,msg,Toast.LENGTH_LONG).show(); finish();
        });
    }
    private Map<Integer,String> parse(String text){ LinkedHashMap<Integer,String> m=new LinkedHashMap<>(); for(String line:text.split("\\R")){ Matcher z=P.matcher(line); if(z.matches()) try{m.put(Integer.parseInt(z.group(1)),z.group(2).trim());}catch(Exception ignored){} } return m; }
}
